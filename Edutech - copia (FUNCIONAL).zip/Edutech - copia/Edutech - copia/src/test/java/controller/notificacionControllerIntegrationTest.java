package controller;

import com.example.demo.model.Notificacion;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

public class notificacionControllerIntegrationTest {
    


public class NotificacionControllerTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void shouldCreateNotificacion() {
        Notificacion noti = new Notificacion();
        noti.setMensaje("Tu clase comienza en 5 minutos");
        noti.setDestinatario("Recordatorio");

        ResponseEntity<Notificacion> response = restTemplate.postForEntity("/api/notificacion", noti, Notificacion.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getDestinatario()).isEqualTo("Recordatorio");
    }
}

}
