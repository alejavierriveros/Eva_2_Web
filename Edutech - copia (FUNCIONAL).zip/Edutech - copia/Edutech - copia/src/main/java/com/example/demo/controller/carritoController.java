package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.*;

import com.example.demo.model.Curso;
import com.example.demo.service.CursoService;

@RestController
@RequestMapping("/api/v2/carrito")

public class carritoController {

    private final List<Curso> carrito = new ArrayList<>();

    @Autowired
    private CursoService cursoServ;

    @PostMapping("/agregar/{id}")
    public String agregarCurso(@PathVariable int id) {
        Curso curso = cursoServ.getCursoId(id);
        if (curso != null && curso.getStock() >= 0) {
            curso.setStock(curso.getStock() - 1);     
            cursoServ.updateCurso(curso); 
            carrito.add(curso); 
            return "Curso agregado al carrito " + curso.getNombre();
        }

        return "Curso no fue encontrado o sin stock";
    }


    @GetMapping()
    public List<Curso> verCarrito() {
        return carrito;
    }

    @DeleteMapping("/eliminar/{id}")
public String eliminarCurso(@PathVariable int id) {
    Iterator<Curso> iterator = carrito.iterator();
    while (iterator.hasNext()) {
        Curso cursoEnCarrito = iterator.next();
        if (cursoEnCarrito.getId() == id) {
            // Restaurar el stock en la base de datos
            Curso original = cursoServ.getCursoId(id);
            if (original != null) {
                original.setStock(original.getStock() + 1);
                cursoServ.updateCurso(original);
            }

            // Remover del carrito
            iterator.remove();
            return "Curso eliminado del carrito y stock restaurado";
            
        }
    }
    return "Curso no estaba en el carrito";
}


    @DeleteMapping("/vaciar")
    public String vaciarCarrito() {
        carrito.clear(); 
        return "Carrito vaciado";
    }


    @PostMapping("/confirmar")
    public String confirmarCompra() {
        Map<Integer, Integer> cantidadPorCurso = new HashMap<>();


        for (Curso curso : carrito) {
            cantidadPorCurso.put(curso.getId(), cantidadPorCurso.getOrDefault(curso.getId(), 0) + 1);
        }


        for (Map.Entry<Integer, Integer> entry : cantidadPorCurso.entrySet()) {
            Curso original = cursoServ.getCursoId(entry.getKey());
            int cantidad = entry.getValue();

            if (original == null || original.getStock() < cantidad) {
                return "No hay stock suficiente para el curso: " + (original != null ? original.getNombre() : "ID " + entry.getKey());
            }
        }




        carrito.clear();
        return "Compra confirmada con éxito.";
    }



    @GetMapping("/total")
    public int totalCursos() {
        return carrito.size();
    }

}