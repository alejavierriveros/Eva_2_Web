const carrito = (()=>{
    const API = "/api/v2/carrito";

    async function listarCarrito(){
        try{
            const response = await fetch(API);
            const cursos = await response.json();
            const tbody = document.querySelector("#tablaCarrito tbody");
            const totalCurso = document.getElementById("totalCarrito");
            tbody.innerHTML ="";
            totalCurso.textContent = cursos.length;

            cursos.forEach(curso => {
                const fila = `
                <tr>
                    <td>${curso.id}</td>
                    <td>${curso.nombre}</td>
                    
                    <td>
                        <button onClick="carrito.eliminarCurso(${curso.id})">Eliminar</button>
                    </td>
                
                `;
                tbody.innerHTML += fila;
            });
        }catch(err) {
            console.error("Error al cargar el carrito", err);
        }
    }

    async function agregarCurso(id){
        try{
            await fetch(`${API}/agregar/${id}`,
                {method : "POST"}
            );
            alert("Curso agregado al carrito");
            listarCarrito();
            listarCursos();
        }catch (err) {
            console.error("Error al agregar al carrito",err);
        }
    }

    async function eliminarCurso(id){
        try{
            await fetch(`${API}/eliminar/${id}`,
                {method:"DELETE"}
            );
            alert ("El curso se elimino del carro");
            listarCarrito();
            listarCursos();
        }catch (err){
            console.error("Error al elminar el curso del carrito", err);
        }
    }

    async function vaciarCarrito(){
        if(confirm("¿Estas seguro de vaciar el carrito?")){
            await fetch(`${API}/vaciar`,
                {method: "DELETE"}
            );
            alert ("El carrito esta vacio.");
            listarCarrito();
        }
    }

   async function confirmarCompra(){
    const total = document.getElementById("totalCarrito").textContent;
    if (parseInt(total) === 0) {
        alert("El carrito está vacío.");
        return;
    }
    if (confirm(`¿Desea confirmar su compra por ${total} curso(s)?`)){
        try {
            const response = await fetch(`${API}/confirmar`, { method: "POST" });
            const mensaje = await response.text();
            alert(mensaje);
            listarCarrito();
            listarCursos();
            if (typeof curso !== 'undefined' && curso.listarCursos) {
                curso.listarCursos(); 
            }
        } catch (err) {
            console.error("Error al confirmar compra", err);
        }
    }
}

     return {listarCarrito,agregarCurso,eliminarCurso,vaciarCarrito,confirmarCompra}
})();