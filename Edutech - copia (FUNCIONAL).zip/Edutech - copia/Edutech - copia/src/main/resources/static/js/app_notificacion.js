
API_URL = "http://localhost:8080/api/notificaciones";
document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("formNotificacion");
    const lista = document.getElementById("listaNotificaciones");

    const notificaciones = JSON.parse(localStorage.getItem("notificaciones")) || [];
    renderizarNotificaciones();


    form.addEventListener("submit", (e) => {
        e.preventDefault();

        const mensaje = document.getElementById("mensaje").value.trim();
        const destinatario = document.getElementById("destinatario").value.trim();

        if (!mensaje || !destinatario) return;

        const nuevaNotificacion = {
            id: Date.now(),
            mensaje,
            destinatario,
            leida: false
        };

        notificaciones.push(nuevaNotificacion);
        localStorage.setItem("notificaciones", JSON.stringify(notificaciones));

        form.reset();
        renderizarNotificaciones();
    });


    window.marcarTodasComoLeidas = () => {
        notificaciones = notificaciones.map(n => ({ ...n, leida: true }));
        localStorage.setItem("notificaciones", JSON.stringify(notificaciones));
        renderizarNotificaciones();
    };

    window.cerrarSesion = () => {
        localStorage.clear();
        window.location.href = "index.html";
    };


    function renderizarNotificaciones() {
        lista.innerHTML = "";

        if (notificaciones.length === 0) {
            lista.innerHTML = `<p class="text-muted">No hay notificaciones.</p>`;
            return;
        }

        notificaciones.slice().reverse().forEach(notificacion => {
            const col = document.createElement("div");
            col.className = "col-md-6 mb-3";

            const card = document.createElement("div");
            card.className = `notification-card card p-3 ${notificacion.leida ? "bg-light" : "bg-white"}`;

            card.innerHTML = `
                <div class="card-body">
                    <h5 class="card-title">Para: ${notificacion.destinatario}</h5>
                    <p class="card-text">${notificacion.mensaje}</p>
                    <button class="btn btn-sm btn-outline-primary mt-2" ${notificacion.leida ? "disabled" : ""
                }>Marcar como leída</button>
                </div>
            `;

            const boton = card.querySelector("button");
            boton.addEventListener("click", () => {
                notificacion.leida = true;
                localStorage.setItem("notificaciones", JSON.stringify(notificaciones));
                renderizarNotificaciones();
            });

            col.appendChild(card);
            lista.appendChild(col);
        });
    }
});