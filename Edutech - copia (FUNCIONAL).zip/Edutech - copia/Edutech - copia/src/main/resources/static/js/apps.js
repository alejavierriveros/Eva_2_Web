const API_URL = "http://localhost:8080/api/cursos";

function listarCursos() {
    fetch(API_URL)
        .then(response => response.json())
        .then(cursos => {
            const tbody = document.querySelector("#tablaCursos tbody");
            tbody.innerHTML = "";
            cursos.forEach(curso => {
                const fila = `
                    <tr>
                        <td>${curso.id}</td>
                        <td>${curso.nombre}</td>
                        <td>${curso.stock}</td>
                        <td> 
                            <button class="btn btn-success btn-sm" onclick="carrito.agregarCurso(${curso.id})"> Agregar </button>
                            <button class="btn btn-danger btn-sm" onclick="eliminarCurso(${curso.id})">🗑️ Eliminar</button> 
                            <button class="btn btn-warning btn-sm" onclick="buscarCurso(${curso.id})">✏️ Editar</button> 
                        </td>
                    </tr>
                `;
                tbody.innerHTML += fila;
            });
        });
}
let cursos=[];
function agregarCurso(){
    const nombre=document.getElementById("nombre").value;
    const stock = parseInt(document.getElementById("stock").value);
    const nuevoCurso={
        nombre,
        stock
    };
    fetch (API_URL,{
        method:"POST",
        headers:{"Content-Type": "application/json"},
        body:JSON.stringify(nuevoCurso)
    })
    .then(response=>response.json())
    .then(data=>{
        alert("Curso agregado exitosamente");
        listarCursos();
        LimpiarFormularios();
    });
}
function eliminarCurso(id){
    fetch(`${API_URL}/${id}`,{method:"DELETE"})
    .then(response=>{
        if(response.ok){
            alert("Curso eliminado exitosamente");
            listarCursos();
        }
    });
}



let cursoEnEdicionId=null;
function buscarCurso(id){
    fetch(`${API_URL}/${id}`)
    .then(response=> response.json())
    .then(curso=>{
        document.getElementById("nombre").value=curso.nombre;
        document.getElementById("stock").value = curso.stock;

        cursoEnEdicionId=curso.id;

        const boton =document.getElementById("botonFormulario");
        if(boton){
            boton.textContent="Actualizar curso";
            boton.onclick=function(){
                actualizarCurso(curso.id);
            };
        }
    }); 
}





function actualizarCurso(id){
    const nombre=document.getElementById("nombre").value;
    const stock = parseInt(document.getElementById("stock").value);
    const cursoActualizado={
        id:id,
        nombre:nombre,
        stock: stock
    };

   fetch(`${API_URL}/${id}`,{
    method:"PUT",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify(cursoActualizado)
   })
   .then(response=>response.json())
   .then(data=>{
        alert("Curso actualizado exitosamente");
        listarCursos();
        LimpiarFormularios();
   });
}



function LimpiarFormularios(){
    document.getElementById("nombre").value="";
    document.getElementById("stock").value = "";
    
    const boton=document.getElementById("botonFormulario");
    boton.innerText="Agregar curso";
    boton.setAttribute("onclick","agregarCurso()");

    cursoEnEdicionId=null;
}
listarCursos();
