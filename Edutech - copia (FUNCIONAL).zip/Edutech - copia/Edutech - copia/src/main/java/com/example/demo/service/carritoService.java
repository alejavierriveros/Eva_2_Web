package com.example.demo.service;

import com.example.demo.model.carrito;
import com.example.demo.repository.carritoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class carritoService {

    private final carritoRepository repo;

    public carritoService(carritoRepository repo) {
        this.repo = repo;
    }

    public List<carrito> findAll() {
        return repo.findAll();
    }

    public Optional<carrito> findById(Long id) {
        return repo.findById(id);
    }

    public List<carrito> findByCorreoUsuario(String correo) {
        return repo.findByCorreoUsuario(correo);
    }

    public carrito save(carrito carrito) {
        return repo.save(carrito);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    public void deleteByCorreoUsuario(String correo) {
        List<carrito> items = repo.findByCorreoUsuario(correo);
        repo.deleteAll(items);
    }
}
