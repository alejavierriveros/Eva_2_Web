package com.example.demo.service;

import com.example.demo.model.Curso;
import com.example.demo.repository.CursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CursoService {
    @Autowired
    private CursoRepository cursoRepository;

    public List<Curso> getCurso() {
        return cursoRepository.findAll();
    }

    public Curso saveCurso(Curso curso) {
        return cursoRepository.save(curso);
    }

    public Curso getCursoId(int id) {
        return cursoRepository.findById(id).orElse(null);
    }

    public Curso updateCurso(Curso curso) {
        return cursoRepository.save(curso);
    }

    public String deleteCurso(int id) {
        cursoRepository.deleteById(id);
        return "curso eliminado";
    }

    public int totalLibros() {
        return (int) cursoRepository.count();
    }

    public int totalLibrosV2() {
        return totalLibros();
    }
}

