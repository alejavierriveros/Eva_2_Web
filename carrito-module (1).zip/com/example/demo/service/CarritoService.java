package com.example.demo.service;

import com.example.demo.model.Carrito;
import com.example.demo.repository.CarritoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CarritoService {

    private final CarritoRepository repo;

    public CarritoService(CarritoRepository repo) {
        this.repo = repo;
    }

    public List<Carrito> findAll() {
        return repo.findAll();
    }

    public Optional<Carrito> findById(Long id) {
        return repo.findById(id);
    }

    public List<Carrito> findByCorreoUsuario(String correo) {
        return repo.findByCorreoUsuario(correo);
    }

    public Carrito save(Carrito carrito) {
        return repo.save(carrito);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    public void deleteByCorreoUsuario(String correo) {
        List<Carrito> items = repo.findByCorreoUsuario(correo);
        repo.deleteAll(items);
    }
}
