package controller;
import com.example.demo.controller.carritoController;
import com.example.demo.model.Curso;
import com.example.demo.service.CursoService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@WebMvcTest(carritoController.class)
public class cursoControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CursoService cursoService;

    private Curso cursoEjemplo;

    @BeforeEach
    void setUp() {
        cursoEjemplo = new Curso( );
    }

    @Test
    void agregarCurso_alCarrito_debeResponderConfirmacion() throws Exception {
        when(cursoService.getCursoId(1)).thenReturn(cursoEjemplo);

        mockMvc.perform(post("/api/v1/carrito/agregar/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Curso agregado al carrito: Clean Code"));
    }

    @Test
    void verCarrito_debeMostrarCursosAgregados() throws Exception {
        when(cursoService.getCursoId(1)).thenReturn(cursoEjemplo);
        mockMvc.perform(post("/api/v1/carrito/agregar/1"));

        mockMvc.perform(get("/api/v1/carrito"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nombre").value("Clean Code"));
    }

    @Test
    void eliminarCurso_delCarrito_debeEliminarCorrectamente() throws Exception {
        when(cursoService.getCursoId(1)).thenReturn(cursoEjemplo);
        mockMvc.perform(post("/api/v1/carrito/agregar/1"));

        mockMvc.perform(delete("/api/v1/carrito/eliminar/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Curso eliminado del carrito"));
    }

    @Test
    void vaciarCarrito_debeResponderCorrectamente() throws Exception {
        when(cursoService.getCursoId(1)).thenReturn(cursoEjemplo);
        mockMvc.perform(post("/api/v1/carrito/agregar/1"));

        mockMvc.perform(delete("/api/v1/carrito/vaciar"))
                .andExpect(status().isOk())
                .andExpect(content().string("Carrito vaciado"));
    }

    @Test
    void totalCursosCarrito_debeRetornarCantidad() throws Exception {
        when(cursoService.getCursoId(1)).thenReturn(cursoEjemplo);
        mockMvc.perform(post("/api/v1/carrito/agregar/1"));

        mockMvc.perform(get("/api/v1/carrito/total"))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }

    
}
