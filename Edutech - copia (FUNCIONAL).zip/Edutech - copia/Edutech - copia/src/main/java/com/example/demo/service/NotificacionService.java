package com.example.demo.service;

import com.example.demo.model.Notificacion;
import com.example.demo.repository.NotificacionRepository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class NotificacionService {
    @Autowired
    private NotificacionRepository notificacionRepository;

    public List<Notificacion> obtenerTodas() {
        return notificacionRepository.findAll();
    }

    public Optional<Notificacion> obtenerPorId(Long id) {
        return notificacionRepository.findById(id);
    }

    public Notificacion guardar(Notificacion notificacion) {
        return notificacionRepository.save(notificacion);
    }

    public void eliminar(Long id) {
        notificacionRepository.deleteById(id);
    }

    public Notificacion actualizar(Long id, Notificacion nuevaNotificacion) {
        return notificacionRepository.findById(id)
                .map(notificacionExistente -> {
                    notificacionExistente.setMensaje(nuevaNotificacion.getMensaje());
                    notificacionExistente.setDestinatario(nuevaNotificacion.getDestinatario());
                    return notificacionRepository.save(notificacionExistente);
                })
                .orElseGet(() -> {
                    nuevaNotificacion.setId(id);
                    return notificacionRepository.save(nuevaNotificacion);
                });
    }
}