package controller;


import com.example.demo.controller.usuarioController;
import com.example.demo.model.usuario;
import com.example.demo.service.usuarioService;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.http.MediaType;

import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.mockito.ArgumentMatchers.any;

import static org.mockito.Mockito.when;

import java.util.Optional;

@WebMvcTest(usuarioController.class)
public class usuarioControllerIntegrationTest {
    
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private usuarioService usuarioService;

    @Autowired

    private ObjectMapper objectMapper;

    @Test
    void registraUsuario_ReturnGuardar() throws Exception{
        usuario newUser = new usuario();
        newUser.setNombre("Camilo");
        newUser.setEmail("camilo@gmail.com");
        newUser.setPassword("1234");


        when(usuarioService.registrar(any(usuario.class)))
            .thenReturn(newUser);


       mockMvc.perform(post("/api/v1/usuarios/registrar")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(newUser)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Carlos"))
            .andExpect(jsonPath("$.email").value("carlos@gmail.com"))
            .andExpect(jsonPath("$.password").value("1234"));
    }
    
    @Test
    void loginUsuario_ReturnError() throws Exception{
        usuario userError = new usuario();
        userError.setEmail("noexiste@gmail.com");
        userError.setPassword("1234");

        when(usuarioService.autenticar("noexiste@gmail.com", "1234")).thenReturn(Optional.empty());

        mockMvc.perform(post("/api/v1/usuarios/login")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(userError)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.result").value("ERROR"));

    }

}
