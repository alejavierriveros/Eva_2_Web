package com.example.demo.controller;

import com.example.demo.model.Carrito;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class CarritoControllerTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void shouldCreateCarrito() {
        Carrito carrito = new Carrito();
        carrito.setNombreCurso("Física Cuántica");
        carrito.setPrecio(45000);

        ResponseEntity<Carrito> response = restTemplate.postForEntity("/api/carrito", carrito, Carrito.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getNombreCurso()).isEqualTo("Física Cuántica");
    }
}
