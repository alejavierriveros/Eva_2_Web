package com.example.demo.controller;

import com.example.demo.model.Carrito;
import com.example.demo.service.CarritoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/carrito")
public class CarritoController {

    private final CarritoService service;

    public CarritoController(CarritoService service) {
        this.service = service;
    }

    @GetMapping
    public List<Carrito> getAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public Carrito getById(@PathVariable Long id) {
        return service.findById(id).orElse(null);
    }

    @GetMapping("/usuario/{correo}")
    public List<Carrito> getByCorreoUsuario(@PathVariable String correo) {
        return service.findByCorreoUsuario(correo);
    }

    @PostMapping
    public Carrito add(@RequestBody Carrito carrito) {
        return service.save(carrito);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        service.delete(id);
    }

    @DeleteMapping("/usuario/{correo}")
    public void deleteByCorreoUsuario(@PathVariable String correo) {
        service.deleteByCorreoUsuario(correo);
    }
}
