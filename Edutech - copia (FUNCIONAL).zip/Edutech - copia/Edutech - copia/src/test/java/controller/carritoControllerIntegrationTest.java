package controller;

import com.example.demo.model.carrito;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import static org.assertj.core.api.Assertions.assertThat;

public class carritoControllerIntegrationTest {
    
    @SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
    public class CarritoControllerTest {

        @Autowired
        private TestRestTemplate restTemplate;

        @Test
        void shouldCreateCarrito() {
            carrito carrito = new carrito();
            carrito.setNombreCurso("Física Cuántica");
            carrito.setPrecio(45000);

            ResponseEntity<carrito> response = restTemplate.postForEntity("/api/carrito", carrito, carrito.class);
            assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
            assertThat(response.getBody().getNombreCurso()).isEqualTo("Física Cuántica");
        }
    }

}
