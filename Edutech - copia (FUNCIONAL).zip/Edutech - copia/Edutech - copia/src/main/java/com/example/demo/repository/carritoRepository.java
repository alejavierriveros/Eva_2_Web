package com.example.demo.repository;

import com.example.demo.model.carrito;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface carritoRepository extends JpaRepository<carrito, Long> {
    List<carrito> findByCorreoUsuario(String correoUsuario);
}
