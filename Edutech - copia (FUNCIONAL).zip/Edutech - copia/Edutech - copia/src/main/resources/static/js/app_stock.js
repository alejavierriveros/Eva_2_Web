const API_URL = 'http://localhost:8080/api/stock';

async function cargarStocks() {
    const res = await fetch(API_URL);
    const data = await res.json();

    const tbody = document.getElementById('stock-table-body');
    tbody.innerHTML = '';

    data.forEach(stock => {
        const row = document.createElement('tr');
        row.innerHTML = `
      <td>${stock.id}</td>
      <td>${stock.nombre}</td>
      <td>${stock.cantidad}</td>
      <td>
        <button onclick="eliminarStock(${stock.id})">Eliminar</button>
      </td>
    `;
        tbody.appendChild(row);
    });

    actualizarTotal();
}

async function agregarStock() {
    const id = document.getElementById('id').value;
    const nombre = document.getElementById('nombre').value;
    const cantidad = document.getElementById('cantidad').value;

    await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, nombre, cantidad })
    });

    document.getElementById('id').value = '';
    document.getElementById('nombre').value = '';
    document.getElementById('cantidad').value = '';

    cargarStocks();
}

async function eliminarStock(id) {
    await fetch(`${API_URL}/${id}`, {
        method: 'DELETE'
    });
    cargarStocks();
}

async function actualizarTotal() {
    const res = await fetch(`${API_URL}/total`);
    const total = await res.text();
    document.getElementById('total-cantidad').innerText = total;
}

document.addEventListener('DOMContentLoaded', cargarStocks);